/* ========================================================================== */
/* PROJECT VORTEX-ION: CO-LOCATED IN-SITU SAFETY CORE ASSEMBLY STARTUP LAYERS */
/* TARGET HARDWARE: Cortex-M4 Execution Vector Core (STM32H747 M4 Environment)*/
/* REVISION STATUS: RESOLVED SINGLE-PASS BRANCH FREEZE -> MAPPED TO MAIN()    */
/* ========================================================================== */

.syntax unified
.cpu cortex-m4
.fpu fpv4-sp-d16
.thumb

.global g_pfnVectors
.global Reset_Handler
.global main                          /* Explicitly import main execution entry point */

/* -------------------------------------------------------------------------- */
/* VECTOR INTERRUPT TABLE SPECIFICATION BLOCK                                 */
/* -------------------------------------------------------------------------- */
.section .isr_vector,"a",%progbits
.type g_pfnVectors, %object

g_pfnVectors:
  .word _estack                       /* Top of Stack Pointer Anchor Address */
  .word Reset_Handler                 /* Reset Execution Origin Vector       */
  .word NMI_Handler                   /* Non-Maskable Interrupt Handler      */
  .word HardFault_Handler             /* Hardware Memory Trap Handler        */
  .word MemManage_Handler             /* Memory Management Fault             */
  .word BusFault_Handler              /* Bus Error Vector                    */
  .word UsageFault_Handler            /* Instruction Execution Fault         */
  .fill 4, 4, 0                       /* Reserved Vector Positions           */
  .word SVC_Handler                   /* System Service Call Vector          */
  .word DebugMon_Handler              /* Debug Monitor Handler               */
  .fill 1, 4, 0                       /* Reserved Position                   */
  .word PendSV_Handler                /* Pending System Vector Allocation    */
  .word SysTick_Handler               /* Internal Clock Core Heartbeat       */
  
  /* VERIFIED SILICON LAYOUT: True STM32H7 Core Line Interrupt Mapping Matrix */
  .fill 108, 4, 0                     /* Clear all standard peripheral IRQs up to 107 */
  .word COMP_IRQHandler               /* Offset 108: Dual Analog Comparator Interrupt Vector */
  .fill 41, 4, 0                      /* Clear remaining peripheral vector allocations (Total 150) */

.size g_pfnVectors, .-g_pfnVectors

/* -------------------------------------------------------------------------- */
/* CORE RESET INITIALIZATION ROUTINE                                          */
/* -------------------------------------------------------------------------- */
.section .text.Reset_Handler,"ax",%progbits
.type Reset_Handler, %function

Reset_Handler:
  /* 1. Explicitly initialize Main Stack Pointer register */
  ldr sp, =_estack

  /* 2. Unpack Relocated Vector Table from Flash LMA to SRAM4 VMA */
  ldr r0, =_si_isr_vector             
  ldr r1, =_sisr_vector               
  ldr r2, =_eisr_vector               
  b LoopCopyVectors

CopyVectors:
  ldr r3, [r0], #4
  str r3, [r1], #4

LoopCopyVectors:
  cmp r1, r2
  bcc CopyVectors

  /* 3. Unpack Relocated Code Runtimes (.ramfunc) from Flash LMA to SRAM4 VMA */
  ldr r0, =_si_ramfunc
  ldr r1, =_sramfunc
  ldr r2, =_eramfunc
  b LoopCopyRamFunc

CopyRamFunc:
  ldr r3, [r0], #4
  str r3, [r1], #4

LoopCopyRamFunc:
  cmp r1, r2
  bcc CopyRamFunc

  /* 4. Unpack Initialized Parameters (.data) from Flash LMA to SRAM4 VMA */
  ldr r0, =_sidata
  ldr r1, =_sdata
  ldr r2, =_edata
  b LoopCopyData

CopyData:
  ldr r3, [r0], #4
  str r3, [r1], #4

LoopCopyData:
  cmp r1, r2
  bcc CopyData

  /* 5. Sanitize and Clear Uninitialized Global Variables (.bss Block) */
  ldr r0, =_sbss
  ldr r1, =_ebss
  movs r2, #0
  b LoopClearBss

ClearBss:
  str r2, [r0], #4

LoopClearBss:
  cmp r0, r1
  bcc ClearBss

  /* 6. System Relocation: Point SCB->VTOR to the newly loaded vector block in SRAM4 */
  ldr r0, =0xE000ED08                 /* SCB_VTOR Register Absolute Address */
  ldr r1, =_sisr_vector               /* Address of RAM-relocated vectors    */
  str r1, [r0]
  dsb sy
  isb sy

  /* 7. FIXED: Hand off execution to the Main Master Scheduler Engine */
  bl main

Infinite_System_Hold:
  wfi
  b Infinite_System_Hold

.size Reset_Handler, .-Reset_Handler

/* -------------------------------------------------------------------------- */
/* EXCEPTION EXECUTABLE FALLBACK TEMPLATES                                   */
/* -------------------------------------------------------------------------- */
.section .text.Default_Handler,"ax",%progbits

Default_Handler:
  ldr r0, =0x58021818                 /* FIXED: VXI_GPIOG_BSRR Register Address (Bit Set/Reset) */
  ldr r1, =0x00000080                 /* FIXED: Direct bit mask for Pin 7 ONLY (Bit 7 Set High) */
  str r1, [r0]                        /* Clean atomic bit set: Opens pneumatics, shields adjacent channels */
  dsb sy
Fault_Trap:
  b Fault_Trap

.size Default_Handler, .-Default_Handler

/* Macro-driven allocation mapping unexpected faults cleanly to Default_Handler */
.macro Provide_Vector handler_name
  .weak \handler_name
  .thumb_set \handler_name, Default_Handler
.endm

Provide_Vector NMI_Handler
Provide_Vector HardFault_Handler
Provide_Vector MemManage_Handler
Provide_Vector BusFault_Handler
Provide_Vector UsageFault_Handler
Provide_Vector SVC_Handler
Provide_Vector DebugMon_Handler
Provide_Vector PendSV_Handler
Provide_Vector SysTick_Handler
Provide_Vector COMP_IRQHandler

.end