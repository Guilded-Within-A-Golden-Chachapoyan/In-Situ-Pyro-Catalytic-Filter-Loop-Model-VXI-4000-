/* ========================================================================== */
/* PROJECT VORTEX-ION: CO-LOCATED IN-SITU APPLICATION BRAIN & YIELD ENGINE    */
/* TARGET HARDWARE: Cortex-M7 Flash Execution Core (STM32H747 M7 Environment) */
/* REVISION STATUS: TOTAL CACHE BOUNDARY SYNCHRONIZATION - PRODUCTION FINAL   */
/* ========================================================================== */

#include "vortex_ion_insitu.h"

// Statically pinned to August 2026 LME Spot Realities ($3,785.00 / MT)
#define VXI_LME_ZINC_PRICE_KG      3.785f   
#define VXI_TARGET_DAILY_CATCH_KG  450.0f   
#define VXI_OPERATING_DAYS_YEAR    300UL    

/* Hardware Register Core Mappings for Official STM32H747 Reset & Clock Control */
#define VXI_RCC_BASE               0x58024400UL
#define VXI_RCC_AHB3ENR            (*(volatile uint32_t * const)(VXI_RCC_BASE + 0xD4))  // Bus Matrix Clock Enable
#define VXI_RCC_GCR                (*(volatile uint32_t * const)(VXI_RCC_BASE + 0x00))  // Global Core Release Control

/* Hardlocked 32-Byte L1 Data Cache Maintenance Intrinsics [ysD9J5] */
/* Enforces unified structure-wide invalidation to eliminate line granularity overwrites */
static inline void __attribute__((always_inline)) VXI_Invalidate_Unified_Telemetry_Line(void) {
    __asm volatile("dsb sy" : : : "memory");
    // Force complete 32-byte cache line invalidation containing the full telemetry struct
    __asm volatile("dc ivac, %0" : : "r"(VXI_CORE_STATE) : "memory");
    __asm volatile("dsb sy; isb sy" : : : "memory");
}

static inline void __attribute__((always_inline)) VXI_Clean_Unified_Telemetry_Line(void) {
    __asm volatile("dsb sy" : : : "memory");
    // Force complete 32-byte cache line flush pushing all variables down to SRAM4
    __asm volatile("dc cvac, %0" : : "r"(VXI_CORE_STATE) : "memory");
    __asm volatile("dsb sy; isb sy" : : : "memory");
}

static uint32_t last_watchdog_count = 0;

/**
 * @brief Evaluates the health and heartbeat performance of the M4 Safety Core.
 * Enforces unified cache-line macro block operations to prevent memory degradation.
 */
static void VXI_Monitor_Safety_Core_Heartbeat(void) {
    // Refresh the complete 32-byte structure in cache to safely check all active fields
    VXI_Invalidate_Unified_Telemetry_Line();
    
    uint32_t current_m4_heartbeat = VXI_CORE_STATE->watchdog_heartbeat;
    
    if (current_m4_heartbeat == last_watchdog_count) {
        // Direct reference lvalue write to trip the pneumatic bypass loops
        VXI_GPIOG_ODR |= VXI_PIN_BYPASS_DAMPER;
        __asm volatile("dsb sy" : : : "memory");
        
        /* Enforce strict C11 hardware atomics on shared memory blocks.
           This generates LDREX/STREX instructions to fully shield concurrent M4 modifications. */
        __atomic_or_fetch(&(VXI_CORE_STATE->system_fault_register), VXI_FAULT_HARDWARE_EXTI, __ATOMIC_SEQ_CST);
        
        // Push the unified update immediately out of L1 cache and down to physical RAM
        VXI_Clean_Unified_Telemetry_Line();
    }
    
    last_watchdog_count = current_m4_heartbeat;
}

/**
 * @brief Streams real-time operational yields and computes cash flow analytics.
 */
static void VXI_Process_Economic_Metrics(void) {
    VXI_Invalidate_Unified_Telemetry_Line();
    uint32_t total_press_strokes = VXI_CORE_STATE->physical_baler_cycles;
    
    /* Safely perform local alignment cast extraction to protect FPU execution frames */
    float total_mass_reclaimed_kg = (float)total_press_strokes * 0.5f;
    float current_asset_yield_usd = total_mass_reclaimed_kg * VXI_LME_ZINC_PRICE_KG;
    
    volatile float* const plant_yield_register = (volatile float * const)(0x58004000UL); 
    *plant_yield_register = current_asset_yield_usd;
}

/**
 * @brief Main execution entry point for the high-performance Cortex-M7 Core.
 */
int main(void) {
    __asm volatile("dsb sy; isb sy" : : : "memory");
    
    /* ---------------------------------------------------------------------- */
    /* MASTER DATA STRUCTURE RESET SEQUENCE                                   */
    /* ---------------------------------------------------------------------- */
    // Zero out the shared data map fields cleanly while the safety core is held in reset
    VXI_CORE_STATE->timestamp_ticks = 0;
    VXI_CORE_STATE->differential_pressure_kpa = 0.0f;
    VXI_CORE_STATE->pyrometer_temp_ch_a = 0.0f;
    VXI_CORE_STATE->pyrometer_temp_ch_b = 0.0f;
    VXI_CORE_STATE->nitrogen_purge_pressure = 0.0f;
    VXI_CORE_STATE->system_fault_register = VXI_FAULT_NONE;
    VXI_CORE_STATE->physical_baler_cycles = 0;
    VXI_CORE_STATE->watchdog_heartbeat = 0;
    
    // Commit the complete clean block down to physical RAM 
    VXI_Clean_Unified_Telemetry_Line();
    
    /* ---------------------------------------------------------------------- */
    /* SILICON BOOT SEQUENCE FOR THE CORTEX-M4 SECURITY CORE                  */
    /* ---------------------------------------------------------------------- */
    // 1. Enable the clock access trees for the D2SRAM1 and SRAM4 bus matrix fences
    VXI_RCC_AHB3ENR |= (1UL << 28) | (1UL << 30); 
    __asm volatile("dsb sy; isb sy" : : : "memory");
    
    // 2. Clear the hardware boot-hold register bit inside GCR to release the M4 reset vector safely
    VXI_RCC_GCR |= 0x00000001UL; 
    __asm volatile("dsb sy; isb sy" : : : "memory");
    
    /* ---------------------------------------------------------------------- */
    /* MASTER SCHEDULER LOOP (CONTINUOUS PLC RUNTIME)                         */
    /* ---------------------------------------------------------------------- */
    while (1) {
        VXI_CORE_STATE->timestamp_ticks++;
        
        // Task 1: Check safety core heartbeat every scheduled administrative cycle
        if (VXI_CORE_STATE->timestamp_ticks % 1000 == 0) {
            VXI_Monitor_Safety_Core_Heartbeat();
        }
        
        // Task 2: Update economic performance models based on real-time baler data
        if (VXI_CORE_STATE->timestamp_ticks % 5000 == 0) {
            VXI_Process_Economic_Metrics();
        }
        
        // Hardened Execution Barrier: Use a clean inline execution constraint
        __asm volatile("nop" : : : "memory");
        
        // Regulated hardware loop delay frame to stabilize schedule pacing
        for (volatile uint32_t delay = 0; delay < 20000; delay++) {
            __asm volatile("" : : : "memory");
        }
    }
    
    return 0; 
}