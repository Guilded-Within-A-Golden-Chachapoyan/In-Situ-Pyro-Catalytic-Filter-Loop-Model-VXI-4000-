/* ========================================================================== */
/* PROJECT VORTEX-ION: CO-LOCATED IN-SITU SAFETY CORE ASSEMBLY STARTUP LAYERS */
/* TARGET HARDWARE: Cortex-M4 Execution Vector Core (STM32H747 M4 Environment)*/
/* REVISION STATUS: ENFORCED WORD-ALIGNED COPY SECTORS - PRODUCTION READY     */
/* ========================================================================== */

.syntax unified
.cpu cortex-m4
.fpu fpv4-sp-d16
.thumb

.global g_pfnVectors
.global Reset_Handler
.global main                          /* Explicitly import main execution entry point */

/* -------------------------------------------------------------------------- */
/* VECTOR INTERRUPT TABLE SPECIFICATION BLOCK                                 */
/* -------------------------------------------------------------------------- */
.section .isr_vector,"a",%progbits
.type g_pfnVectors, %object

g_pfnVectors:
  .word _estack                       /* Top of Stack Pointer Anchor Address */
  .word Reset_Handler                 /* Reset Execution Origin Vector       */
  .word NMI_Handler                   /* Non-Maskable Interrupt Handler      */
  .word HardFault_Handler             /* Hardware Memory Trap Handler        */
  .word MemManage_Handler             /* Memory Management Fault             */
  .word BusFault_Handler              /* Bus Error Vector                    */
  .word UsageFault_Handler            /* Instruction Execution Fault         */
  .fill 4, 4, 0                       /* Reserved Vector Positions           */
  .word SVC_Handler                   /* System Service Call Vector          */
  .word DebugMon_Handler              /* Debug Monitor Handler               */
  .fill 1, 4, 0                       /* Reserved Position                   */
  .word PendSV_Handler                /* Pending System Vector Allocation    */
  .word SysTick_Handler               /* Internal Clock Core Heartbeat       */
  
  /* FIXED SILICON LAYOUT: Hardware Core Interrupt Mapping Vector Matrix for STM32H747 */
  .fill 73, 4, 0                      /* Clear all standard peripheral IRQs up to 72 */
  .word COMP_IRQHandler               /* Offset 73: EXTI Line 21 Comparator Intercept Loop [ysD9J5] */
  .fill 76, 4, 0                      /* Clear remaining peripheral vectors (Total 150) */

/* Fixed Size Evaluation Location: Placed correctly AFTER the data definitions */
.size g_pfnVectors, .-g_pfnVectors

/* -------------------------------------------------------------------------- */
/* CORE RESET INITIALIZATION ROUTINE                                          */
/* -------------------------------------------------------------------------- */
.section .text.Reset_Handler,"ax",%progbits
.type Reset_Handler, %function

Reset_Handler:
  /* 1. Explicitly initialize Main Stack Pointer register */
  ldr sp, =_estack

  /* 2. Unpack Relocated Vector Table from Flash LMA to SRAM4 VMA [ysD9J5] */
  ldr r0, =_si_isr_vector             /* Load Flash source memory pointer  */
  ldr r1, =_sisr_vector               /* Load SRAM4 start pointer          */
  ldr r2, =_eisr_vector               /* Load SRAM4 end pointer            */
  b LoopCopyVectors

CopyVectors:
  ldr r3, [r0], #4
  str r3, [r1], #4

LoopCopyVectors:
  cmp r1, r2
  bcc CopyVectors

  /* 3. Unpack Relocated Code Runtimes (.ramfunc) from Flash LMA to SRAM4 VMA [ysD9J5] */
  ldr r0, =_si_ramfunc
  ldr r1, =_sramfunc
  ldr r2, =_eramfunc
  b LoopCopyRamFunc

CopyRamFunc:
  ldr r3, [r0], #4
  str r3, [r1], #4

LoopCopyRamFunc:
  cmp r1, r2
  bcc CopyRamFunc

  /* 4. Unpack Initialized Parameters (.data) from Flash LMA to SRAM4 VMA [ysD9J5] */
  ldr r0, =_sidata
  ldr r1, =_sdata
  ldr r2, =_edata
  b LoopCopyData

CopyData:
  ldr r3, [r0], #4
  str r3, [r1], #4

LoopCopyData:
  cmp r1, r2
  bcc CopyData

  /* 5. Sanitize and Clear Uninitialized Global Variables (.bss Block) */
  /* Optimized Architecture: Relies on Linker Script . = ALIGN(4) to land exactly on _ebss */
  ldr r0, =_sbss
  ldr r1, =_ebss
  movs r2, #0
  b LoopClearBss

ClearBss:
  str r2, [r0], #4

LoopClearBss:
  cmp r0, r1
  bcc ClearBss

  /* 6. System Relocation: Point SCB->VTOR to the newly loaded vector block in SRAM4 [ysD9J5] */
  ldr r0, =0xE000ED08                 /* SCB_VTOR Register Absolute Address */
  ldr r1, =_sisr_vector               /* Address of RAM-relocated vectors    */
  str r1, [r0]
  dsb sy
  isb sy

  /* 7. Hand off execution cleanly to the Main Master Scheduler Engine */
  bl main

Infinite_System_Hold:
  wfi
  b Infinite_System_Hold

.size Reset_Handler, .-Reset_Handler

/* -------------------------------------------------------------------------- */
/* EXCEPTION EXECUTABLE FALLBACK TEMPLATES                                   */
/* -------------------------------------------------------------------------- */
.section .text.Default_Handler,"ax",%progbits

Default_Handler:
  /* Fixed Register Hazard: Perform atomic store to BSRR register to open fallback path safely */
  ldr r0, =0x58021818                 /* VXI_GPIOG_BSRR Register Address    */
  ldr r1, =0x00000180                 /* Fixed: Sets BOTH Pin 7 (Bit 7) and Pin 8 (Bit 8) High simultaneously */
  str r1, [r0]                        /* Clean atomic direct hardware write */
  dsb sy
Fault_Trap:
  b Fault_Trap

.size Default_Handler, .-Default_Handler

/* Macro-driven allocation mapping unexpected faults cleanly to Default_Handler */
.macro Provide_Vector handler_name
  .weak \handler_name
  .thumb_set \handler_name, Default_Handler
.endm

Provide_Vector NMI_Handler
Provide_Vector HardFault_Handler
Provide_Vector MemManage_Handler
Provide_Vector BusFault_Handler
Provide_Vector UsageFault_Handler
Provide_Vector SVC_Handler
Provide_Vector DebugMon_Handler
Provide_Vector PendSV_Handler
Provide_Vector SysTick_Handler

/* Fix: COMP_IRQHandler removed from macro loop to guarantee strong external C binding */

.end