/* ========================================================================== */
/* PROJECT VORTEX-ION: CO-LOCATED IN-SITU SAFETY CORE TELEMETRY TRACKER      */
/* TARGET HARDWARE: Cortex-M4 Secure Execution Core (STM32H747 M4 Environment)*/
/* REVISION STATUS: CORRECTED EXTI REGISTER W1C LOOP - PRODUCTION READY       */
/* ========================================================================== */

#include "vortex_ion_insitu.h"

// External linker markers mapping the absolute boundaries of the user stack
extern uint32_t _sstack; // Defined dynamically in your production linker script

/* CMSIS Core Pipeline Barrier Intrinsics definition fallback */
#ifndef __DSB
  #define __DSB() __asm volatile("dsb sy" : : : "memory")
#endif
#ifndef __ISB
  #define __ISB() __asm volatile("isb sy" : : : "memory")
#endif
#ifndef __WFI
  #define __WFI() __asm volatile("wfi" : : : "memory")
#endif

/* ========================================================================== */
/* HARDWARE INTERRUPT & COMPREHENSIVE BITWISE SANITIZED TRIPPING LOGIC        */
/* ========================================================================== */

/**
 * @brief Executes an instantaneous physical fallback shutdown.
 * Directly drives the dereferenced GPIO hardware register high to open the pneumatic 
 * bypass loop and drop the counterweighted gravity-dropped isolation gate.
 */
static inline void __attribute__((always_inline)) VXI_Execute_Instant_Fallback(void) {
    // Assert both PG7 (Bypass Latch) and PG8 (Emergency Gate Release) high using type-safe masks
    VXI_GPIOG_ODR |= (VXI_PIN_BYPASS_DAMPER | VXI_PIN_EMERGENCY_GATE);
}

/**
 * @brief Dynamic stack-overflow verification method.
 * Checks the physical location of the stack pointer register at runtime.
 * If a boundary breach occurs, it acts purely on hardware to protect against memory corruption.
 */
static inline void __attribute__((always_inline)) VXI_Assert_Stack_Integrity(void) {
    register uint32_t current_sp __asm("sp"); // Grab live stack register address
    
    // Check if downward stack execution has breached your defined 2K boundary barrier
    if (current_sp <= (uint32_t)&_sstack) {
        // Immediate hardware override: Force physical pin triggers instantly
        VXI_Execute_Instant_Fallback();
        __DSB(); // Force immediate hardware memory data serialization barrier
        __ISB(); // Flush pipeline to guarantee execution state
        
        // Error-Proofing: Avoid writing to corrupted RAM loops. 
        // Stop execution instantly to freeze core and let M7 catch the watchdog timeout.
        while(1) {
            __WFI(); 
        }
    }
}

/**
 * @brief Fully error-proofed continuous monitoring loop running on Core Cortex-M4.
 * Integrates zero-overhead __builtin_memcpy and explicit atomic pointer qualifiers.
 */
void __attribute__((optimize("O3"), section(".ramfunc"))) VXI_Execute_Safety_Loop(void) {
    
    /* ---------------------------------------------------------------------- */
    /* RUNTIME PROTECTION LAYER 1: STACK INTEGRITY BOUNDS RUNTIME CHECK      */
    /* ---------------------------------------------------------------------- */
    VXI_Assert_Stack_Integrity();

    /* ---------------------------------------------------------------------- */
    /* CORE TELEMETRY PARSING LAYER                                           */
    /* ---------------------------------------------------------------------- */
    // Read local structural snapshots from volatile shared memory space
    float current_dP       = VXI_CORE_STATE->differential_pressure_kpa;
    float current_nitrogen = VXI_CORE_STATE->nitrogen_purge_pressure;
    
    /* ---------------------------------------------------------------------- */
    /* RUNTIME PROTECTION LAYER 2: TYPE-SAFE STRICT-ALIASING SENSOR CHECK     */
    /* ---------------------------------------------------------------------- */
    uint32_t dp_raw_bits;
    uint32_t n2_raw_bits;
    
    // Satisfy explicit -O3 strict aliasing constraints via compiler memory copy intrinsics
    __builtin_memcpy(&dp_raw_bits, &current_dP, 4);
    __builtin_memcpy(&n2_raw_bits, &current_nitrogen, 4);
    
    // Check for NaN or Infinity signatures (all 8 exponent bits set to 1)
    if (((dp_raw_bits & 0x7F800000UL) == 0x7F800000UL) || 
        ((n2_raw_bits & 0x7F800000UL) == 0x7F800000UL)) {
        
        // Severe hardware sensor corruption caught: Trigger absolute physical fallback instantly
        VXI_Execute_Instant_Fallback();
        VXI_CORE_STATE->system_fault_register |= VXI_FAULT_HARDWARE_EXTI;
        __DSB(); /* Fix: Boundary fence placed AFTER write to force external visibility */
        return; // Break execution cycle immediately to insulate the machinery
    }

    /* ---------------------------------------------------------------------- */
    /* RUNTIME PROTECTION LAYER 3: THRESHOLD LOGIC EXPECTATIONS               */
    /* ---------------------------------------------------------------------- */
    // Rule A: Filter Over-Pressure Evaluation
    if (current_dP >= VXI_TRIP_THRESHOLD_DP_KPA) {
        VXI_GPIOG_ODR |= VXI_PIN_BYPASS_DAMPER;
        VXI_CORE_STATE->system_fault_register |= VXI_FAULT_CRITICAL_DP;
        __DSB(); /* Fix: Pipeline fence placed at terminal edge to lock data synchronization */
    }
    
    // Rule B: Purge Nitrogen Depletion Evaluation
    if (current_nitrogen < VXI_MIN_PURGE_PRESS_PSI) {
        VXI_Execute_Instant_Fallback();
        VXI_CORE_STATE->system_fault_register |= VXI_FAULT_LOW_NITROGEN;
        __DSB(); /* Fix: Pipeline fence placed at terminal edge to lock data synchronization */
    }
    
    /* ---------------------------------------------------------------------- */
    /* VERIFIABLE SYSTEM HEARTBEAT                                           */
    /* ---------------------------------------------------------------------- */
    // Fix: Changed literal from '1UL' to standard unsigned '1U' to eliminate size truncation warnings
    __atomic_fetch_add((uint32_t *)&VXI_CORE_STATE->watchdog_heartbeat, 1U, __ATOMIC_SEQ_CST);
}

/**
 * @brief Hardware Vector Interrupt Service Routine for EXTI Line 21.
 * Standard clean function signature matching hardware stack frame context saving.
 */
void __attribute__((section(".ramfunc"))) COMP_IRQHandler(void) {
    VXI_Execute_Instant_Fallback();
    VXI_CORE_STATE->system_fault_register |= VXI_FAULT_HARDWARE_EXTI;
    __DSB();
    
    // Clear pending interrupt flag for EXTI Line 21 safely via single direct store.
    volatile uint32_t* const exti_pr1 = (volatile uint32_t * const)(0x58000000UL + 0x88);
    *exti_pr1 = (1UL << 21);
    __DSB();
}